/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatatoJtable;

/**
 *
 * @author ARFAH
 */
class User {
    private String event_id,event_name,venue,edate,charge,contact,email,duration,endtime;
    public User(String event_id, String event_name, String venue, String edate, String charge, String contact, String email,String duration,String endtime)
    {
        this.event_id=event_id;
        this.event_name=event_name;
        this.venue=venue;
        this.edate=edate;
        this.charge=charge;
        this.contact=contact;
        this.email=email;
        this.duration=duration;
        this.endtime=endtime;
    }
    public String getevent_id(){
        return event_id;
                }
    public String getevent_name(){
        return event_name;
                }
    public String getvenue(){
        return venue;
                }
    public String getedate(){
        return edate;
                }
    public String getcharge(){
        return charge;
                }
    public String getcontact(){
        return contact;
                }
    public String getemail(){
        return email;
                }
    public String getduration(){
        return duration;
                }
    public String getendtime(){
        return endtime;
                }

   
    
    }

